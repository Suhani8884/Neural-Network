function y = tanhprim(x)
% TANHPRIM Derivative of tanh

y = 1 - tanh(x).^2;

