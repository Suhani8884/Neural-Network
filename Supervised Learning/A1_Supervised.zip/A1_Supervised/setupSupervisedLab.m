% SETUPSUPERVISEDLAB Run this script to setup the lab environment

addpath(pwd)
addpath data
addpath helpFunctions
addpath kNN
addpath multiLayerNetwork
addpath singleLayerNetwork